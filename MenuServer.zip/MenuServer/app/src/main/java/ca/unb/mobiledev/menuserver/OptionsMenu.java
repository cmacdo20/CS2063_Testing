package ca.unb.mobiledev.menuserver;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.ToggleButton;

import androidx.appcompat.app.AppCompatActivity;

public class OptionsMenu extends AppCompatActivity {
    // _Definitions_
    public static final String TAG = "OptionsMenu";
    private ToggleButton toggle1;
    private ToggleButton toggle2;
    private ToggleButton toggle3;
    private ToggleButton toggle4;

    // _Methods_
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // Initialize layout
        Log.d(TAG,"onCreate() was called!!!");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.options_menu);
        getSupportActionBar().hide();

        // Retrieve game settings and initialize button states
        toggle1 = findViewById(R.id.toggle1);
        toggle1.setChecked(MainMenu.tiltControlsEnabled);
        toggle2 = findViewById(R.id.toggle2);
        toggle2.setChecked(MainMenu.audioEffectsEnabled);
        toggle3 = findViewById(R.id.toggle3);
        toggle3.setChecked(MainMenu.musicEnabled);
        toggle4 = findViewById(R.id.toggle4);
        toggle4.setChecked(MainMenu.practiceModeEnabled);

        // Toggle button 1 behaviour
        toggle1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                SharedPreferences.Editor editor = MainMenu.prefs.edit();
                if (isChecked) {
                    MainMenu.tiltControlsEnabled = true;
                    editor.putBoolean(MainMenu.TILT_ENABLED_KEY, true);
                } else {
                    MainMenu.tiltControlsEnabled = false;
                    editor.putBoolean(MainMenu.TILT_ENABLED_KEY, false);
                }
                editor.apply();
            }
        });

        // Toggle button 2 behaviour
        toggle2.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                SharedPreferences.Editor editor = MainMenu.prefs.edit();
                if (isChecked) {
                    MainMenu.audioEffectsEnabled = true;
                    editor.putBoolean(MainMenu.AUDIO_ENABLED_KEY, true);
                } else {
                    MainMenu.audioEffectsEnabled = false;
                    editor.putBoolean(MainMenu.AUDIO_ENABLED_KEY, false);
                }
                editor.apply();
            }
        });

        // Toggle button 3 behaviour
        toggle3.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                SharedPreferences.Editor editor = MainMenu.prefs.edit();
                if (isChecked) {
                    MainMenu.musicEnabled = true;
                    editor.putBoolean(MainMenu.MUSIC_ENABLED_KEY, true);
                } else {
                    MainMenu.musicEnabled = false;
                    editor.putBoolean(MainMenu.MUSIC_ENABLED_KEY, false);
                }
                editor.apply();
            }
        });

        // Toggle button 4 behaviour
        toggle4.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                SharedPreferences.Editor editor = MainMenu.prefs.edit();
                if (isChecked) {
                    MainMenu.practiceModeEnabled = true;
                    editor.putBoolean(MainMenu.PRACTICE_ENABLED_KEY, true);
                } else {
                    MainMenu.practiceModeEnabled = false;
                    editor.putBoolean(MainMenu.PRACTICE_ENABLED_KEY, false);
                }
                editor.apply();
            }
        });
    }
}
