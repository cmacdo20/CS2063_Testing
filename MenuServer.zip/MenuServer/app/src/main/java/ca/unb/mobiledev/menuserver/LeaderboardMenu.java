package ca.unb.mobiledev.menuserver;

import android.content.Context;
import android.database.Cursor;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class LeaderboardMenu extends AppCompatActivity {
    private DBManager dbManager;
    private ListView mListView;
    private ExecutorService executor;
    private Handler handler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.leaderboard_menu);
        getSupportActionBar().hide();

        // Set the executor service
        executor = Executors.newSingleThreadExecutor();
        handler = new Handler(Looper.getMainLooper());

        // Retrieve listview
        mListView = findViewById(R.id.listview);

        // Create a new DBManager object
        dbManager = new DBManager(this);
        setUpListView();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        dbManager.close();
    }

    private void setUpListView() {
        // Cursor query attributes
        final String[] FROM = {DatabaseHelper.PLAYER_NAME, DatabaseHelper.SCORE};
        final int[] TO = {R.id.name_textview, R.id.score_textview};

        executor.execute(() -> {
            // Perform background call to retrieve the records
            Cursor cursor = dbManager.listAllRecords();

            handler.post(() -> {
                // Update the UI with the results
                SimpleCursorAdapter adapter = new SimpleCursorAdapter(this,
                                              R.layout.leaderboard_layout, cursor, FROM, TO, 0);
                adapter.notifyDataSetChanged();
                mListView.setAdapter(adapter);
            });
        });
    }

    private void addItem(String player, String score) {
        executor.execute(() -> {
            // Perform background call to save the record
            dbManager.insertRecord(player, score);

            // Update the UI with the results
            handler.post(this::setUpListView);
        });
    }

    private void deleteItem(int id) {
        executor.execute(() -> {
            // Perform background call to remove the record
            dbManager.deleteRecord(id);

            // Update the UI with the results
            handler.post(this::setUpListView);
        });
    }
}
