package ca.unb.mobiledev.menuserver;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class PauseMenuFragment extends Fragment {
    // _Definitions_
    public static final String TAG = "PauseMenuFragment";
    private GameView gameView;

    // _Constructors_
    public PauseMenuFragment() { }

    public static PauseMenuFragment newInstance(GameView gameView) {
        PauseMenuFragment fragment = new PauseMenuFragment();
        fragment.setGameView(gameView);
        return fragment;
    }

    // _View_Behaviour_
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        // Inflate layout
        View view = inflater.inflate(R.layout.pause_menu_fragment, container, false);
        Log.d(TAG, "Pause menu inflated!!!");

        // Resume button behaviour
        Button resumeBtn = view.findViewById(R.id.resume_button_pause);
        resumeBtn.setOnClickListener( v -> {
            Log.d(TAG, "Resume button pressed!!!");
            gameView.gameResume();
        });

        // Resume button behaviour
        Button restartBtn = view.findViewById(R.id.restart_button_pause);
        resumeBtn.setOnClickListener( v -> {
            Log.d(TAG, "Restart button pressed!!!");
        });

        // Resume button behaviour
        Button quitBtn = view.findViewById(R.id.quit_button_pause);
        resumeBtn.setOnClickListener( v -> {
            Log.d(TAG, "Quit button pressed!!!");
            gameView.gameResume();
        });

        // Return layout
        return view;
    }

    public void setGameView(GameView gameView) {
        this.gameView = gameView;
    }
}