package ca.unb.mobiledev.menuserver;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainMenu extends AppCompatActivity {
    // _Definitions_
    public static final String TAG = "MainMenu";
    public static final String PREFS_FILENAME = "SpaceForksAppPrefs";
    public static final String TILT_ENABLED_KEY = "tiltControlsEnabled";
    public static final String AUDIO_ENABLED_KEY = "audioEffectsEnabled";
    public static final String MUSIC_ENABLED_KEY = "musicEnabled";
    public static final String PRACTICE_ENABLED_KEY = "practiceModeEnabled";
    public static final String PREVNAME_KEY = "prevName";
    public static boolean tiltControlsEnabled;
    public static boolean audioEffectsEnabled;
    public static boolean musicEnabled;
    public static boolean practiceModeEnabled;
    public static String prevName;
    public static SharedPreferences prefs;

    // _onCreate()_
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // Initialize layout
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_menu);
        getSupportActionBar().hide();

        Button startButton = findViewById(R.id.start_button);
        Button optionsButton = findViewById(R.id.options_button);
        Button leaderboardButton = findViewById(R.id.leaderboard_button);

        // Retrieve shared preferences
        initSharedPreferences();

        // Start button behaviour
        startButton.setOnClickListener( v -> {
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
        });

        // Options button behaviour
        optionsButton.setOnClickListener( v -> {
            Intent intent = new Intent(this, OptionsMenu.class);
            startActivity(intent);
            Log.d(TAG, "Start options menu!!!");
         });

        // Leaderboard button behaviour
        leaderboardButton.setOnClickListener( v -> {
            Intent intent = new Intent(this, LeaderboardMenu.class);
            startActivity(intent);
            Log.d(TAG,"Start leaderboard menu!!!");
        });
    }

    // _Public_Methods_
    public static String getPrevName() {
        return prevName;
    }

    // _Private_Methods_
    private void initSharedPreferences() {
        // Retrieve shared preferences object
        prefs = getSharedPreferences(PREFS_FILENAME, Context.MODE_PRIVATE);

        // Retrieve and set game options (defaults are second argument)
        tiltControlsEnabled = prefs.getBoolean(TILT_ENABLED_KEY, true);
        audioEffectsEnabled = prefs.getBoolean(AUDIO_ENABLED_KEY, true);
        musicEnabled = prefs.getBoolean(MUSIC_ENABLED_KEY, true);
        practiceModeEnabled = prefs.getBoolean(PRACTICE_ENABLED_KEY, false);
        prevName = prefs.getString(PREVNAME_KEY, "SpaceCadet1");
    }
}